// Generated from Schema.g4 by ANTLR 4.0
import org.antlr.v4.runtime.tree.*;
import org.antlr.v4.runtime.Token;

public interface SchemaVisitor<T> extends ParseTreeVisitor<T> {
	T visitAddFirstProp(SchemaParser.AddFirstPropContext ctx);

	T visitLoad(SchemaParser.LoadContext ctx);

	T visitQuery(SchemaParser.QueryContext ctx);

	T visitEvalNumberValue(SchemaParser.EvalNumberValueContext ctx);

	T visitSchema(SchemaParser.SchemaContext ctx);

	T visitGetFirstCSVEntry(SchemaParser.GetFirstCSVEntryContext ctx);

	T visitGetCSVBool(SchemaParser.GetCSVBoolContext ctx);

	T visitCommand(SchemaParser.CommandContext ctx);

	T visitEvalBoolValue(SchemaParser.EvalBoolValueContext ctx);

	T visitEqualTo(SchemaParser.EqualToContext ctx);

	T visitLetType(SchemaParser.LetTypeContext ctx);

	T visitCsvfile(SchemaParser.CsvfileContext ctx);

	T visitGetNextConstraint(SchemaParser.GetNextConstraintContext ctx);

	T visitGetCSVNumber(SchemaParser.GetCSVNumberContext ctx);

	T visitGetCSVQstr(SchemaParser.GetCSVQstrContext ctx);

	T visitGetCSVRecord(SchemaParser.GetCSVRecordContext ctx);

	T visitGetNextCSVEntry(SchemaParser.GetNextCSVEntryContext ctx);

	T visitEvalConstraint(SchemaParser.EvalConstraintContext ctx);

	T visitClarifyType(SchemaParser.ClarifyTypeContext ctx);

	T visitEvalQStringValue(SchemaParser.EvalQStringValueContext ctx);

	T visitGetQuery(SchemaParser.GetQueryContext ctx);

	T visitGetsym(SchemaParser.GetsymContext ctx);

	T visitAddNextProp(SchemaParser.AddNextPropContext ctx);

	T visitDeclareProp(SchemaParser.DeclarePropContext ctx);

	T visitQueryfile(SchemaParser.QueryfileContext ctx);

	T visitGetFirstConstraint(SchemaParser.GetFirstConstraintContext ctx);
}