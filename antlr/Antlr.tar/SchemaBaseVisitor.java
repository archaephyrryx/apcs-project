// Generated from Schema.g4 by ANTLR 4.0
import org.antlr.v4.runtime.tree.*;
import org.antlr.v4.runtime.Token;
import org.antlr.v4.runtime.ParserRuleContext;

public class SchemaBaseVisitor<T> extends AbstractParseTreeVisitor<T> implements SchemaVisitor<T> {
	@Override public T visitAddFirstProp(SchemaParser.AddFirstPropContext ctx) { return visitChildren(ctx); }

	@Override public T visitLoad(SchemaParser.LoadContext ctx) { return visitChildren(ctx); }

	@Override public T visitQuery(SchemaParser.QueryContext ctx) { return visitChildren(ctx); }

	@Override public T visitEvalNumberValue(SchemaParser.EvalNumberValueContext ctx) { return visitChildren(ctx); }

	@Override public T visitSchema(SchemaParser.SchemaContext ctx) { return visitChildren(ctx); }

	@Override public T visitGetFirstCSVEntry(SchemaParser.GetFirstCSVEntryContext ctx) { return visitChildren(ctx); }

	@Override public T visitGetCSVBool(SchemaParser.GetCSVBoolContext ctx) { return visitChildren(ctx); }

	@Override public T visitCommand(SchemaParser.CommandContext ctx) { return visitChildren(ctx); }

	@Override public T visitEvalBoolValue(SchemaParser.EvalBoolValueContext ctx) { return visitChildren(ctx); }

	@Override public T visitEqualTo(SchemaParser.EqualToContext ctx) { return visitChildren(ctx); }

	@Override public T visitLetType(SchemaParser.LetTypeContext ctx) { return visitChildren(ctx); }

	@Override public T visitCsvfile(SchemaParser.CsvfileContext ctx) { return visitChildren(ctx); }

	@Override public T visitGetNextConstraint(SchemaParser.GetNextConstraintContext ctx) { return visitChildren(ctx); }

	@Override public T visitGetCSVNumber(SchemaParser.GetCSVNumberContext ctx) { return visitChildren(ctx); }

	@Override public T visitGetCSVQstr(SchemaParser.GetCSVQstrContext ctx) { return visitChildren(ctx); }

	@Override public T visitGetCSVRecord(SchemaParser.GetCSVRecordContext ctx) { return visitChildren(ctx); }

	@Override public T visitGetNextCSVEntry(SchemaParser.GetNextCSVEntryContext ctx) { return visitChildren(ctx); }

	@Override public T visitEvalConstraint(SchemaParser.EvalConstraintContext ctx) { return visitChildren(ctx); }

	@Override public T visitClarifyType(SchemaParser.ClarifyTypeContext ctx) { return visitChildren(ctx); }

	@Override public T visitEvalQStringValue(SchemaParser.EvalQStringValueContext ctx) { return visitChildren(ctx); }

	@Override public T visitGetQuery(SchemaParser.GetQueryContext ctx) { return visitChildren(ctx); }

	@Override public T visitGetsym(SchemaParser.GetsymContext ctx) { return visitChildren(ctx); }

	@Override public T visitAddNextProp(SchemaParser.AddNextPropContext ctx) { return visitChildren(ctx); }

	@Override public T visitDeclareProp(SchemaParser.DeclarePropContext ctx) { return visitChildren(ctx); }

	@Override public T visitQueryfile(SchemaParser.QueryfileContext ctx) { return visitChildren(ctx); }

	@Override public T visitGetFirstConstraint(SchemaParser.GetFirstConstraintContext ctx) { return visitChildren(ctx); }
}