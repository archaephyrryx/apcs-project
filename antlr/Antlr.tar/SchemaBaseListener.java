// Generated from Schema.g4 by ANTLR 4.0

import org.antlr.v4.runtime.ParserRuleContext;
import org.antlr.v4.runtime.Token;
import org.antlr.v4.runtime.tree.TerminalNode;
import org.antlr.v4.runtime.tree.ErrorNode;

public class SchemaBaseListener implements SchemaListener {
	@Override public void enterAddFirstProp(SchemaParser.AddFirstPropContext ctx) { }
	@Override public void exitAddFirstProp(SchemaParser.AddFirstPropContext ctx) { }

	@Override public void enterLoad(SchemaParser.LoadContext ctx) { }
	@Override public void exitLoad(SchemaParser.LoadContext ctx) { }

	@Override public void enterQuery(SchemaParser.QueryContext ctx) { }
	@Override public void exitQuery(SchemaParser.QueryContext ctx) { }

	@Override public void enterEvalNumberValue(SchemaParser.EvalNumberValueContext ctx) { }
	@Override public void exitEvalNumberValue(SchemaParser.EvalNumberValueContext ctx) { }

	@Override public void enterSchema(SchemaParser.SchemaContext ctx) { }
	@Override public void exitSchema(SchemaParser.SchemaContext ctx) { }

	@Override public void enterGetFirstCSVEntry(SchemaParser.GetFirstCSVEntryContext ctx) { }
	@Override public void exitGetFirstCSVEntry(SchemaParser.GetFirstCSVEntryContext ctx) { }

	@Override public void enterGetCSVBool(SchemaParser.GetCSVBoolContext ctx) { }
	@Override public void exitGetCSVBool(SchemaParser.GetCSVBoolContext ctx) { }

	@Override public void enterCommand(SchemaParser.CommandContext ctx) { }
	@Override public void exitCommand(SchemaParser.CommandContext ctx) { }

	@Override public void enterEvalBoolValue(SchemaParser.EvalBoolValueContext ctx) { }
	@Override public void exitEvalBoolValue(SchemaParser.EvalBoolValueContext ctx) { }

	@Override public void enterEqualTo(SchemaParser.EqualToContext ctx) { }
	@Override public void exitEqualTo(SchemaParser.EqualToContext ctx) { }

	@Override public void enterLetType(SchemaParser.LetTypeContext ctx) { }
	@Override public void exitLetType(SchemaParser.LetTypeContext ctx) { }

	@Override public void enterCsvfile(SchemaParser.CsvfileContext ctx) { }
	@Override public void exitCsvfile(SchemaParser.CsvfileContext ctx) { }

	@Override public void enterGetNextConstraint(SchemaParser.GetNextConstraintContext ctx) { }
	@Override public void exitGetNextConstraint(SchemaParser.GetNextConstraintContext ctx) { }

	@Override public void enterGetCSVNumber(SchemaParser.GetCSVNumberContext ctx) { }
	@Override public void exitGetCSVNumber(SchemaParser.GetCSVNumberContext ctx) { }

	@Override public void enterGetCSVQstr(SchemaParser.GetCSVQstrContext ctx) { }
	@Override public void exitGetCSVQstr(SchemaParser.GetCSVQstrContext ctx) { }

	@Override public void enterGetCSVRecord(SchemaParser.GetCSVRecordContext ctx) { }
	@Override public void exitGetCSVRecord(SchemaParser.GetCSVRecordContext ctx) { }

	@Override public void enterGetNextCSVEntry(SchemaParser.GetNextCSVEntryContext ctx) { }
	@Override public void exitGetNextCSVEntry(SchemaParser.GetNextCSVEntryContext ctx) { }

	@Override public void enterEvalConstraint(SchemaParser.EvalConstraintContext ctx) { }
	@Override public void exitEvalConstraint(SchemaParser.EvalConstraintContext ctx) { }

	@Override public void enterClarifyType(SchemaParser.ClarifyTypeContext ctx) { }
	@Override public void exitClarifyType(SchemaParser.ClarifyTypeContext ctx) { }

	@Override public void enterEvalQStringValue(SchemaParser.EvalQStringValueContext ctx) { }
	@Override public void exitEvalQStringValue(SchemaParser.EvalQStringValueContext ctx) { }

	@Override public void enterGetQuery(SchemaParser.GetQueryContext ctx) { }
	@Override public void exitGetQuery(SchemaParser.GetQueryContext ctx) { }

	@Override public void enterGetsym(SchemaParser.GetsymContext ctx) { }
	@Override public void exitGetsym(SchemaParser.GetsymContext ctx) { }

	@Override public void enterAddNextProp(SchemaParser.AddNextPropContext ctx) { }
	@Override public void exitAddNextProp(SchemaParser.AddNextPropContext ctx) { }

	@Override public void enterDeclareProp(SchemaParser.DeclarePropContext ctx) { }
	@Override public void exitDeclareProp(SchemaParser.DeclarePropContext ctx) { }

	@Override public void enterQueryfile(SchemaParser.QueryfileContext ctx) { }
	@Override public void exitQueryfile(SchemaParser.QueryfileContext ctx) { }

	@Override public void enterGetFirstConstraint(SchemaParser.GetFirstConstraintContext ctx) { }
	@Override public void exitGetFirstConstraint(SchemaParser.GetFirstConstraintContext ctx) { }

	@Override public void enterEveryRule(ParserRuleContext ctx) { }
	@Override public void exitEveryRule(ParserRuleContext ctx) { }
	@Override public void visitTerminal(TerminalNode node) { }
	@Override public void visitErrorNode(ErrorNode node) { }
}