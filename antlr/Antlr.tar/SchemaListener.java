// Generated from Schema.g4 by ANTLR 4.0
import org.antlr.v4.runtime.tree.*;
import org.antlr.v4.runtime.Token;

public interface SchemaListener extends ParseTreeListener {
	void enterAddFirstProp(SchemaParser.AddFirstPropContext ctx);
	void exitAddFirstProp(SchemaParser.AddFirstPropContext ctx);

	void enterLoad(SchemaParser.LoadContext ctx);
	void exitLoad(SchemaParser.LoadContext ctx);

	void enterQuery(SchemaParser.QueryContext ctx);
	void exitQuery(SchemaParser.QueryContext ctx);

	void enterEvalNumberValue(SchemaParser.EvalNumberValueContext ctx);
	void exitEvalNumberValue(SchemaParser.EvalNumberValueContext ctx);

	void enterSchema(SchemaParser.SchemaContext ctx);
	void exitSchema(SchemaParser.SchemaContext ctx);

	void enterGetFirstCSVEntry(SchemaParser.GetFirstCSVEntryContext ctx);
	void exitGetFirstCSVEntry(SchemaParser.GetFirstCSVEntryContext ctx);

	void enterGetCSVBool(SchemaParser.GetCSVBoolContext ctx);
	void exitGetCSVBool(SchemaParser.GetCSVBoolContext ctx);

	void enterCommand(SchemaParser.CommandContext ctx);
	void exitCommand(SchemaParser.CommandContext ctx);

	void enterEvalBoolValue(SchemaParser.EvalBoolValueContext ctx);
	void exitEvalBoolValue(SchemaParser.EvalBoolValueContext ctx);

	void enterEqualTo(SchemaParser.EqualToContext ctx);
	void exitEqualTo(SchemaParser.EqualToContext ctx);

	void enterLetType(SchemaParser.LetTypeContext ctx);
	void exitLetType(SchemaParser.LetTypeContext ctx);

	void enterCsvfile(SchemaParser.CsvfileContext ctx);
	void exitCsvfile(SchemaParser.CsvfileContext ctx);

	void enterGetNextConstraint(SchemaParser.GetNextConstraintContext ctx);
	void exitGetNextConstraint(SchemaParser.GetNextConstraintContext ctx);

	void enterGetCSVNumber(SchemaParser.GetCSVNumberContext ctx);
	void exitGetCSVNumber(SchemaParser.GetCSVNumberContext ctx);

	void enterGetCSVQstr(SchemaParser.GetCSVQstrContext ctx);
	void exitGetCSVQstr(SchemaParser.GetCSVQstrContext ctx);

	void enterGetCSVRecord(SchemaParser.GetCSVRecordContext ctx);
	void exitGetCSVRecord(SchemaParser.GetCSVRecordContext ctx);

	void enterGetNextCSVEntry(SchemaParser.GetNextCSVEntryContext ctx);
	void exitGetNextCSVEntry(SchemaParser.GetNextCSVEntryContext ctx);

	void enterEvalConstraint(SchemaParser.EvalConstraintContext ctx);
	void exitEvalConstraint(SchemaParser.EvalConstraintContext ctx);

	void enterClarifyType(SchemaParser.ClarifyTypeContext ctx);
	void exitClarifyType(SchemaParser.ClarifyTypeContext ctx);

	void enterEvalQStringValue(SchemaParser.EvalQStringValueContext ctx);
	void exitEvalQStringValue(SchemaParser.EvalQStringValueContext ctx);

	void enterGetQuery(SchemaParser.GetQueryContext ctx);
	void exitGetQuery(SchemaParser.GetQueryContext ctx);

	void enterGetsym(SchemaParser.GetsymContext ctx);
	void exitGetsym(SchemaParser.GetsymContext ctx);

	void enterAddNextProp(SchemaParser.AddNextPropContext ctx);
	void exitAddNextProp(SchemaParser.AddNextPropContext ctx);

	void enterDeclareProp(SchemaParser.DeclarePropContext ctx);
	void exitDeclareProp(SchemaParser.DeclarePropContext ctx);

	void enterQueryfile(SchemaParser.QueryfileContext ctx);
	void exitQueryfile(SchemaParser.QueryfileContext ctx);

	void enterGetFirstConstraint(SchemaParser.GetFirstConstraintContext ctx);
	void exitGetFirstConstraint(SchemaParser.GetFirstConstraintContext ctx);
}