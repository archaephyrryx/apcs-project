// Generated from Schema.g4 by ANTLR 4.0
import org.antlr.v4.runtime.atn.*;
import org.antlr.v4.runtime.dfa.DFA;
import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.misc.*;
import org.antlr.v4.runtime.tree.*;
import java.util.List;
import java.util.Iterator;
import java.util.ArrayList;

@SuppressWarnings({"all", "warnings", "unchecked", "unused", "cast"})
public class SchemaParser extends Parser {
	protected static final DFA[] _decisionToDFA;
	protected static final PredictionContextCache _sharedContextCache =
		new PredictionContextCache();
	public static final int
		T__0=1, QSTRING=2, TRUE=3, FALSE=4, NUMBER=5, GET=6, AS=7, INT=8, BOOL=9, 
		STR=10, LET=11, LOAD=12, CLARIFY=13, COLON=14, SEMI=15, PERIOD=16, COMMA=17, 
		EQUALS=18, ID=19, WS=20;
	public static final String[] tokenNames = {
		"<INVALID>", "'\n'", "QSTRING", "'true'", "'false'", "NUMBER", "'get'", 
		"'as'", "'int'", "'bool'", "'string'", "'let'", "'load'", "'clarify'", 
		"':'", "';'", "'.'", "','", "'='", "ID", "WS"
	};
	public static final int
		RULE_schema = 0, RULE_command = 1, RULE_querycmd = 2, RULE_queryfile = 3, 
		RULE_queryline = 4, RULE_constraints = 5, RULE_constraint = 6, RULE_comp = 7, 
		RULE_value = 8, RULE_clarifyblock = 9, RULE_letblock = 10, RULE_loadcmd = 11, 
		RULE_proplist = 12, RULE_prop = 13, RULE_ptype = 14, RULE_csvfile = 15, 
		RULE_csvline = 16, RULE_csvrecord = 17, RULE_csventry = 18;
	public static final String[] ruleNames = {
		"schema", "command", "querycmd", "queryfile", "queryline", "constraints", 
		"constraint", "comp", "value", "clarifyblock", "letblock", "loadcmd", 
		"proplist", "prop", "ptype", "csvfile", "csvline", "csvrecord", "csventry"
	};

	@Override
	public String getGrammarFileName() { return "Schema.g4"; }

	@Override
	public String[] getTokenNames() { return tokenNames; }

	@Override
	public String[] getRuleNames() { return ruleNames; }

	@Override
	public ATN getATN() { return _ATN; }

	public SchemaParser(TokenStream input) {
		super(input);
		_interp = new ParserATNSimulator(this,_ATN,_decisionToDFA,_sharedContextCache);
	}
	public static class SchemaContext extends ParserRuleContext {
		public CommandContext command(int i) {
			return getRuleContext(CommandContext.class,i);
		}
		public List<CommandContext> command() {
			return getRuleContexts(CommandContext.class);
		}
		public SchemaContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_schema; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof SchemaListener ) ((SchemaListener)listener).enterSchema(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof SchemaListener ) ((SchemaListener)listener).exitSchema(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof SchemaVisitor ) return ((SchemaVisitor<? extends T>)visitor).visitSchema(this);
			else return visitor.visitChildren(this);
		}
	}

	public final SchemaContext schema() throws RecognitionException {
		SchemaContext _localctx = new SchemaContext(_ctx, getState());
		enterRule(_localctx, 0, RULE_schema);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(43);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while ((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << GET) | (1L << LET) | (1L << LOAD) | (1L << CLARIFY))) != 0)) {
				{
				{
				setState(38); command();
				setState(39); match(1);
				}
				}
				setState(45);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class CommandContext extends ParserRuleContext {
		public LetblockContext letblock() {
			return getRuleContext(LetblockContext.class,0);
		}
		public LoadcmdContext loadcmd() {
			return getRuleContext(LoadcmdContext.class,0);
		}
		public ClarifyblockContext clarifyblock() {
			return getRuleContext(ClarifyblockContext.class,0);
		}
		public QuerycmdContext querycmd() {
			return getRuleContext(QuerycmdContext.class,0);
		}
		public CommandContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_command; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof SchemaListener ) ((SchemaListener)listener).enterCommand(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof SchemaListener ) ((SchemaListener)listener).exitCommand(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof SchemaVisitor ) return ((SchemaVisitor<? extends T>)visitor).visitCommand(this);
			else return visitor.visitChildren(this);
		}
	}

	public final CommandContext command() throws RecognitionException {
		CommandContext _localctx = new CommandContext(_ctx, getState());
		enterRule(_localctx, 2, RULE_command);
		try {
			setState(50);
			switch (_input.LA(1)) {
			case LET:
				enterOuterAlt(_localctx, 1);
				{
				setState(46); letblock();
				}
				break;
			case CLARIFY:
				enterOuterAlt(_localctx, 2);
				{
				setState(47); clarifyblock();
				}
				break;
			case LOAD:
				enterOuterAlt(_localctx, 3);
				{
				setState(48); loadcmd();
				}
				break;
			case GET:
				enterOuterAlt(_localctx, 4);
				{
				setState(49); querycmd();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class QuerycmdContext extends ParserRuleContext {
		public QuerycmdContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_querycmd; }
	 
		public QuerycmdContext() { }
		public void copyFrom(QuerycmdContext ctx) {
			super.copyFrom(ctx);
		}
	}
	public static class QueryContext extends QuerycmdContext {
		public TerminalNode GET() { return getToken(SchemaParser.GET, 0); }
		public TerminalNode QSTRING() { return getToken(SchemaParser.QSTRING, 0); }
		public TerminalNode ID() { return getToken(SchemaParser.ID, 0); }
		public TerminalNode SEMI() { return getToken(SchemaParser.SEMI, 0); }
		public TerminalNode PERIOD() { return getToken(SchemaParser.PERIOD, 0); }
		public QueryContext(QuerycmdContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof SchemaListener ) ((SchemaListener)listener).enterQuery(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof SchemaListener ) ((SchemaListener)listener).exitQuery(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof SchemaVisitor ) return ((SchemaVisitor<? extends T>)visitor).visitQuery(this);
			else return visitor.visitChildren(this);
		}
	}

	public final QuerycmdContext querycmd() throws RecognitionException {
		QuerycmdContext _localctx = new QuerycmdContext(_ctx, getState());
		enterRule(_localctx, 4, RULE_querycmd);
		int _la;
		try {
			_localctx = new QueryContext(_localctx);
			enterOuterAlt(_localctx, 1);
			{
			setState(52); match(GET);
			setState(53); match(ID);
			setState(54); match(QSTRING);
			setState(55);
			_la = _input.LA(1);
			if ( !(_la==SEMI || _la==PERIOD) ) {
			_errHandler.recoverInline(this);
			}
			consume();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class QueryfileContext extends ParserRuleContext {
		public QuerylineContext queryline(int i) {
			return getRuleContext(QuerylineContext.class,i);
		}
		public List<QuerylineContext> queryline() {
			return getRuleContexts(QuerylineContext.class);
		}
		public QueryfileContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_queryfile; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof SchemaListener ) ((SchemaListener)listener).enterQueryfile(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof SchemaListener ) ((SchemaListener)listener).exitQueryfile(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof SchemaVisitor ) return ((SchemaVisitor<? extends T>)visitor).visitQueryfile(this);
			else return visitor.visitChildren(this);
		}
	}

	public final QueryfileContext queryfile() throws RecognitionException {
		QueryfileContext _localctx = new QueryfileContext(_ctx, getState());
		enterRule(_localctx, 6, RULE_queryfile);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(60);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==ID) {
				{
				{
				setState(57); queryline();
				}
				}
				setState(62);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class QuerylineContext extends ParserRuleContext {
		public QuerylineContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_queryline; }
	 
		public QuerylineContext() { }
		public void copyFrom(QuerylineContext ctx) {
			super.copyFrom(ctx);
		}
	}
	public static class GetQueryContext extends QuerylineContext {
		public ConstraintsContext constraints() {
			return getRuleContext(ConstraintsContext.class,0);
		}
		public TerminalNode PERIOD() { return getToken(SchemaParser.PERIOD, 0); }
		public TerminalNode SEMI() { return getToken(SchemaParser.SEMI, 0); }
		public GetQueryContext(QuerylineContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof SchemaListener ) ((SchemaListener)listener).enterGetQuery(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof SchemaListener ) ((SchemaListener)listener).exitGetQuery(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof SchemaVisitor ) return ((SchemaVisitor<? extends T>)visitor).visitGetQuery(this);
			else return visitor.visitChildren(this);
		}
	}

	public final QuerylineContext queryline() throws RecognitionException {
		QuerylineContext _localctx = new QuerylineContext(_ctx, getState());
		enterRule(_localctx, 8, RULE_queryline);
		int _la;
		try {
			_localctx = new GetQueryContext(_localctx);
			enterOuterAlt(_localctx, 1);
			{
			setState(63); constraints(0);
			setState(64);
			_la = _input.LA(1);
			if ( !(_la==SEMI || _la==PERIOD) ) {
			_errHandler.recoverInline(this);
			}
			consume();
			setState(65); match(1);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ConstraintsContext extends ParserRuleContext {
		public int _p;
		public ConstraintsContext(ParserRuleContext parent, int invokingState) { super(parent, invokingState); }
		public ConstraintsContext(ParserRuleContext parent, int invokingState, int _p) {
			super(parent, invokingState);
			this._p = _p;
		}
		@Override public int getRuleIndex() { return RULE_constraints; }
	 
		public ConstraintsContext() { }
		public void copyFrom(ConstraintsContext ctx) {
			super.copyFrom(ctx);
			this._p = ctx._p;
		}
	}
	public static class GetNextConstraintContext extends ConstraintsContext {
		public ConstraintsContext constraints() {
			return getRuleContext(ConstraintsContext.class,0);
		}
		public ConstraintContext constraint() {
			return getRuleContext(ConstraintContext.class,0);
		}
		public TerminalNode COMMA() { return getToken(SchemaParser.COMMA, 0); }
		public GetNextConstraintContext(ConstraintsContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof SchemaListener ) ((SchemaListener)listener).enterGetNextConstraint(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof SchemaListener ) ((SchemaListener)listener).exitGetNextConstraint(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof SchemaVisitor ) return ((SchemaVisitor<? extends T>)visitor).visitGetNextConstraint(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class GetFirstConstraintContext extends ConstraintsContext {
		public ConstraintContext constraint() {
			return getRuleContext(ConstraintContext.class,0);
		}
		public GetFirstConstraintContext(ConstraintsContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof SchemaListener ) ((SchemaListener)listener).enterGetFirstConstraint(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof SchemaListener ) ((SchemaListener)listener).exitGetFirstConstraint(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof SchemaVisitor ) return ((SchemaVisitor<? extends T>)visitor).visitGetFirstConstraint(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ConstraintsContext constraints(int _p) throws RecognitionException {
		ParserRuleContext _parentctx = _ctx;
		int _parentState = getState();
		ConstraintsContext _localctx = new ConstraintsContext(_ctx, _parentState, _p);
		ConstraintsContext _prevctx = _localctx;
		int _startState = 10;
		enterRecursionRule(_localctx, RULE_constraints);
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			{
			_localctx = new GetFirstConstraintContext(_localctx);
			_ctx = _localctx;
			_prevctx = _localctx;

			setState(68); constraint();
			}
			_ctx.stop = _input.LT(-1);
			setState(75);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,3,_ctx);
			while ( _alt!=2 && _alt!=-1 ) {
				if ( _alt==1 ) {
					if ( _parseListeners!=null ) triggerExitRuleEvent();
					_prevctx = _localctx;
					{
					{
					_localctx = new GetNextConstraintContext(new ConstraintsContext(_parentctx, _parentState, _p));
					pushNewRecursionContext(_localctx, _startState, RULE_constraints);
					setState(70);
					if (!(1 >= _localctx._p)) throw new FailedPredicateException(this, "1 >= $_p");
					setState(71); match(COMMA);
					setState(72); constraint();
					}
					} 
				}
				setState(77);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,3,_ctx);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			unrollRecursionContexts(_parentctx);
		}
		return _localctx;
	}

	public static class ConstraintContext extends ParserRuleContext {
		public ConstraintContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_constraint; }
	 
		public ConstraintContext() { }
		public void copyFrom(ConstraintContext ctx) {
			super.copyFrom(ctx);
		}
	}
	public static class EvalConstraintContext extends ConstraintContext {
		public CompContext comp() {
			return getRuleContext(CompContext.class,0);
		}
		public ValueContext value() {
			return getRuleContext(ValueContext.class,0);
		}
		public TerminalNode ID() { return getToken(SchemaParser.ID, 0); }
		public EvalConstraintContext(ConstraintContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof SchemaListener ) ((SchemaListener)listener).enterEvalConstraint(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof SchemaListener ) ((SchemaListener)listener).exitEvalConstraint(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof SchemaVisitor ) return ((SchemaVisitor<? extends T>)visitor).visitEvalConstraint(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ConstraintContext constraint() throws RecognitionException {
		ConstraintContext _localctx = new ConstraintContext(_ctx, getState());
		enterRule(_localctx, 12, RULE_constraint);
		try {
			_localctx = new EvalConstraintContext(_localctx);
			enterOuterAlt(_localctx, 1);
			{
			setState(78); match(ID);
			setState(79); comp();
			setState(80); value();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class CompContext extends ParserRuleContext {
		public CompContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_comp; }
	 
		public CompContext() { }
		public void copyFrom(CompContext ctx) {
			super.copyFrom(ctx);
		}
	}
	public static class EqualToContext extends CompContext {
		public TerminalNode EQUALS() { return getToken(SchemaParser.EQUALS, 0); }
		public EqualToContext(CompContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof SchemaListener ) ((SchemaListener)listener).enterEqualTo(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof SchemaListener ) ((SchemaListener)listener).exitEqualTo(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof SchemaVisitor ) return ((SchemaVisitor<? extends T>)visitor).visitEqualTo(this);
			else return visitor.visitChildren(this);
		}
	}

	public final CompContext comp() throws RecognitionException {
		CompContext _localctx = new CompContext(_ctx, getState());
		enterRule(_localctx, 14, RULE_comp);
		try {
			_localctx = new EqualToContext(_localctx);
			enterOuterAlt(_localctx, 1);
			{
			setState(82); match(EQUALS);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ValueContext extends ParserRuleContext {
		public ValueContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_value; }
	 
		public ValueContext() { }
		public void copyFrom(ValueContext ctx) {
			super.copyFrom(ctx);
		}
	}
	public static class EvalNumberValueContext extends ValueContext {
		public Token v;
		public TerminalNode NUMBER() { return getToken(SchemaParser.NUMBER, 0); }
		public EvalNumberValueContext(ValueContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof SchemaListener ) ((SchemaListener)listener).enterEvalNumberValue(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof SchemaListener ) ((SchemaListener)listener).exitEvalNumberValue(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof SchemaVisitor ) return ((SchemaVisitor<? extends T>)visitor).visitEvalNumberValue(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class EvalQStringValueContext extends ValueContext {
		public Token v;
		public TerminalNode QSTRING() { return getToken(SchemaParser.QSTRING, 0); }
		public EvalQStringValueContext(ValueContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof SchemaListener ) ((SchemaListener)listener).enterEvalQStringValue(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof SchemaListener ) ((SchemaListener)listener).exitEvalQStringValue(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof SchemaVisitor ) return ((SchemaVisitor<? extends T>)visitor).visitEvalQStringValue(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class EvalBoolValueContext extends ValueContext {
		public Token v;
		public TerminalNode FALSE() { return getToken(SchemaParser.FALSE, 0); }
		public TerminalNode TRUE() { return getToken(SchemaParser.TRUE, 0); }
		public EvalBoolValueContext(ValueContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof SchemaListener ) ((SchemaListener)listener).enterEvalBoolValue(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof SchemaListener ) ((SchemaListener)listener).exitEvalBoolValue(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof SchemaVisitor ) return ((SchemaVisitor<? extends T>)visitor).visitEvalBoolValue(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ValueContext value() throws RecognitionException {
		ValueContext _localctx = new ValueContext(_ctx, getState());
		enterRule(_localctx, 16, RULE_value);
		int _la;
		try {
			setState(87);
			switch (_input.LA(1)) {
			case NUMBER:
				_localctx = new EvalNumberValueContext(_localctx);
				enterOuterAlt(_localctx, 1);
				{
				setState(84); ((EvalNumberValueContext)_localctx).v = match(NUMBER);
				}
				break;
			case TRUE:
			case FALSE:
				_localctx = new EvalBoolValueContext(_localctx);
				enterOuterAlt(_localctx, 2);
				{
				setState(85);
				((EvalBoolValueContext)_localctx).v = _input.LT(1);
				_la = _input.LA(1);
				if ( !(_la==TRUE || _la==FALSE) ) {
					((EvalBoolValueContext)_localctx).v = (Token)_errHandler.recoverInline(this);
				}
				consume();
				}
				break;
			case QSTRING:
				_localctx = new EvalQStringValueContext(_localctx);
				enterOuterAlt(_localctx, 3);
				{
				setState(86); ((EvalQStringValueContext)_localctx).v = match(QSTRING);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ClarifyblockContext extends ParserRuleContext {
		public ClarifyblockContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_clarifyblock; }
	 
		public ClarifyblockContext() { }
		public void copyFrom(ClarifyblockContext ctx) {
			super.copyFrom(ctx);
		}
	}
	public static class ClarifyTypeContext extends ClarifyblockContext {
		public TerminalNode AS() { return getToken(SchemaParser.AS, 0); }
		public TerminalNode CLARIFY() { return getToken(SchemaParser.CLARIFY, 0); }
		public TerminalNode ID() { return getToken(SchemaParser.ID, 0); }
		public TerminalNode SEMI() { return getToken(SchemaParser.SEMI, 0); }
		public TerminalNode PERIOD() { return getToken(SchemaParser.PERIOD, 0); }
		public PtypeContext ptype() {
			return getRuleContext(PtypeContext.class,0);
		}
		public ClarifyTypeContext(ClarifyblockContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof SchemaListener ) ((SchemaListener)listener).enterClarifyType(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof SchemaListener ) ((SchemaListener)listener).exitClarifyType(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof SchemaVisitor ) return ((SchemaVisitor<? extends T>)visitor).visitClarifyType(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ClarifyblockContext clarifyblock() throws RecognitionException {
		ClarifyblockContext _localctx = new ClarifyblockContext(_ctx, getState());
		enterRule(_localctx, 18, RULE_clarifyblock);
		int _la;
		try {
			_localctx = new ClarifyTypeContext(_localctx);
			enterOuterAlt(_localctx, 1);
			{
			setState(89); match(CLARIFY);
			setState(90); ptype();
			setState(91); match(AS);
			setState(92); match(ID);
			setState(93);
			_la = _input.LA(1);
			if ( !(_la==SEMI || _la==PERIOD) ) {
			_errHandler.recoverInline(this);
			}
			consume();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class LetblockContext extends ParserRuleContext {
		public LetblockContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_letblock; }
	 
		public LetblockContext() { }
		public void copyFrom(LetblockContext ctx) {
			super.copyFrom(ctx);
		}
	}
	public static class LetTypeContext extends LetblockContext {
		public TerminalNode ID() { return getToken(SchemaParser.ID, 0); }
		public ProplistContext proplist() {
			return getRuleContext(ProplistContext.class,0);
		}
		public TerminalNode SEMI() { return getToken(SchemaParser.SEMI, 0); }
		public TerminalNode PERIOD() { return getToken(SchemaParser.PERIOD, 0); }
		public TerminalNode LET() { return getToken(SchemaParser.LET, 0); }
		public LetTypeContext(LetblockContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof SchemaListener ) ((SchemaListener)listener).enterLetType(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof SchemaListener ) ((SchemaListener)listener).exitLetType(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof SchemaVisitor ) return ((SchemaVisitor<? extends T>)visitor).visitLetType(this);
			else return visitor.visitChildren(this);
		}
	}

	public final LetblockContext letblock() throws RecognitionException {
		LetblockContext _localctx = new LetblockContext(_ctx, getState());
		enterRule(_localctx, 20, RULE_letblock);
		int _la;
		try {
			_localctx = new LetTypeContext(_localctx);
			enterOuterAlt(_localctx, 1);
			{
			setState(95); match(LET);
			setState(96); match(ID);
			setState(97); proplist(0);
			setState(98);
			_la = _input.LA(1);
			if ( !(_la==SEMI || _la==PERIOD) ) {
			_errHandler.recoverInline(this);
			}
			consume();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class LoadcmdContext extends ParserRuleContext {
		public LoadcmdContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_loadcmd; }
	 
		public LoadcmdContext() { }
		public void copyFrom(LoadcmdContext ctx) {
			super.copyFrom(ctx);
		}
	}
	public static class LoadContext extends LoadcmdContext {
		public TerminalNode QSTRING() { return getToken(SchemaParser.QSTRING, 0); }
		public TerminalNode ID() { return getToken(SchemaParser.ID, 0); }
		public TerminalNode PERIOD() { return getToken(SchemaParser.PERIOD, 0); }
		public TerminalNode SEMI() { return getToken(SchemaParser.SEMI, 0); }
		public TerminalNode LOAD() { return getToken(SchemaParser.LOAD, 0); }
		public LoadContext(LoadcmdContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof SchemaListener ) ((SchemaListener)listener).enterLoad(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof SchemaListener ) ((SchemaListener)listener).exitLoad(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof SchemaVisitor ) return ((SchemaVisitor<? extends T>)visitor).visitLoad(this);
			else return visitor.visitChildren(this);
		}
	}

	public final LoadcmdContext loadcmd() throws RecognitionException {
		LoadcmdContext _localctx = new LoadcmdContext(_ctx, getState());
		enterRule(_localctx, 22, RULE_loadcmd);
		int _la;
		try {
			_localctx = new LoadContext(_localctx);
			enterOuterAlt(_localctx, 1);
			{
			setState(100); match(LOAD);
			setState(101); match(ID);
			setState(102); match(QSTRING);
			setState(103);
			_la = _input.LA(1);
			if ( !(_la==SEMI || _la==PERIOD) ) {
			_errHandler.recoverInline(this);
			}
			consume();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ProplistContext extends ParserRuleContext {
		public int _p;
		public ProplistContext(ParserRuleContext parent, int invokingState) { super(parent, invokingState); }
		public ProplistContext(ParserRuleContext parent, int invokingState, int _p) {
			super(parent, invokingState);
			this._p = _p;
		}
		@Override public int getRuleIndex() { return RULE_proplist; }
	 
		public ProplistContext() { }
		public void copyFrom(ProplistContext ctx) {
			super.copyFrom(ctx);
			this._p = ctx._p;
		}
	}
	public static class AddFirstPropContext extends ProplistContext {
		public PropContext prop() {
			return getRuleContext(PropContext.class,0);
		}
		public AddFirstPropContext(ProplistContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof SchemaListener ) ((SchemaListener)listener).enterAddFirstProp(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof SchemaListener ) ((SchemaListener)listener).exitAddFirstProp(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof SchemaVisitor ) return ((SchemaVisitor<? extends T>)visitor).visitAddFirstProp(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class AddNextPropContext extends ProplistContext {
		public PropContext prop() {
			return getRuleContext(PropContext.class,0);
		}
		public TerminalNode COMMA() { return getToken(SchemaParser.COMMA, 0); }
		public ProplistContext proplist() {
			return getRuleContext(ProplistContext.class,0);
		}
		public AddNextPropContext(ProplistContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof SchemaListener ) ((SchemaListener)listener).enterAddNextProp(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof SchemaListener ) ((SchemaListener)listener).exitAddNextProp(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof SchemaVisitor ) return ((SchemaVisitor<? extends T>)visitor).visitAddNextProp(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ProplistContext proplist(int _p) throws RecognitionException {
		ParserRuleContext _parentctx = _ctx;
		int _parentState = getState();
		ProplistContext _localctx = new ProplistContext(_ctx, _parentState, _p);
		ProplistContext _prevctx = _localctx;
		int _startState = 24;
		enterRecursionRule(_localctx, RULE_proplist);
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			{
			_localctx = new AddFirstPropContext(_localctx);
			_ctx = _localctx;
			_prevctx = _localctx;

			setState(106); prop();
			}
			_ctx.stop = _input.LT(-1);
			setState(113);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,5,_ctx);
			while ( _alt!=2 && _alt!=-1 ) {
				if ( _alt==1 ) {
					if ( _parseListeners!=null ) triggerExitRuleEvent();
					_prevctx = _localctx;
					{
					{
					_localctx = new AddNextPropContext(new ProplistContext(_parentctx, _parentState, _p));
					pushNewRecursionContext(_localctx, _startState, RULE_proplist);
					setState(108);
					if (!(1 >= _localctx._p)) throw new FailedPredicateException(this, "1 >= $_p");
					setState(109); match(COMMA);
					setState(110); prop();
					}
					} 
				}
				setState(115);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,5,_ctx);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			unrollRecursionContexts(_parentctx);
		}
		return _localctx;
	}

	public static class PropContext extends ParserRuleContext {
		public PropContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_prop; }
	 
		public PropContext() { }
		public void copyFrom(PropContext ctx) {
			super.copyFrom(ctx);
		}
	}
	public static class DeclarePropContext extends PropContext {
		public TerminalNode ID() { return getToken(SchemaParser.ID, 0); }
		public PtypeContext ptype() {
			return getRuleContext(PtypeContext.class,0);
		}
		public DeclarePropContext(PropContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof SchemaListener ) ((SchemaListener)listener).enterDeclareProp(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof SchemaListener ) ((SchemaListener)listener).exitDeclareProp(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof SchemaVisitor ) return ((SchemaVisitor<? extends T>)visitor).visitDeclareProp(this);
			else return visitor.visitChildren(this);
		}
	}

	public final PropContext prop() throws RecognitionException {
		PropContext _localctx = new PropContext(_ctx, getState());
		enterRule(_localctx, 26, RULE_prop);
		try {
			_localctx = new DeclarePropContext(_localctx);
			enterOuterAlt(_localctx, 1);
			{
			setState(116); ptype();
			setState(117); match(ID);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class PtypeContext extends ParserRuleContext {
		public PtypeContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_ptype; }
	 
		public PtypeContext() { }
		public void copyFrom(PtypeContext ctx) {
			super.copyFrom(ctx);
		}
	}
	public static class GetsymContext extends PtypeContext {
		public Token t;
		public TerminalNode ID() { return getToken(SchemaParser.ID, 0); }
		public GetsymContext(PtypeContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof SchemaListener ) ((SchemaListener)listener).enterGetsym(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof SchemaListener ) ((SchemaListener)listener).exitGetsym(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof SchemaVisitor ) return ((SchemaVisitor<? extends T>)visitor).visitGetsym(this);
			else return visitor.visitChildren(this);
		}
	}

	public final PtypeContext ptype() throws RecognitionException {
		PtypeContext _localctx = new PtypeContext(_ctx, getState());
		enterRule(_localctx, 28, RULE_ptype);
		try {
			setState(123);
			switch (_input.LA(1)) {
			case INT:
				_localctx = new GetsymContext(_localctx);
				enterOuterAlt(_localctx, 1);
				{
				setState(119); ((GetsymContext)_localctx).t = match(INT);
				}
				break;
			case BOOL:
				_localctx = new GetsymContext(_localctx);
				enterOuterAlt(_localctx, 2);
				{
				setState(120); ((GetsymContext)_localctx).t = match(BOOL);
				}
				break;
			case STR:
				_localctx = new GetsymContext(_localctx);
				enterOuterAlt(_localctx, 3);
				{
				setState(121); ((GetsymContext)_localctx).t = match(STR);
				}
				break;
			case ID:
				_localctx = new GetsymContext(_localctx);
				enterOuterAlt(_localctx, 4);
				{
				setState(122); ((GetsymContext)_localctx).t = match(ID);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class CsvfileContext extends ParserRuleContext {
		public List<CsvlineContext> csvline() {
			return getRuleContexts(CsvlineContext.class);
		}
		public CsvlineContext csvline(int i) {
			return getRuleContext(CsvlineContext.class,i);
		}
		public CsvfileContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_csvfile; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof SchemaListener ) ((SchemaListener)listener).enterCsvfile(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof SchemaListener ) ((SchemaListener)listener).exitCsvfile(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof SchemaVisitor ) return ((SchemaVisitor<? extends T>)visitor).visitCsvfile(this);
			else return visitor.visitChildren(this);
		}
	}

	public final CsvfileContext csvfile() throws RecognitionException {
		CsvfileContext _localctx = new CsvfileContext(_ctx, getState());
		enterRule(_localctx, 30, RULE_csvfile);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(128);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while ((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << QSTRING) | (1L << TRUE) | (1L << FALSE) | (1L << NUMBER))) != 0)) {
				{
				{
				setState(125); csvline();
				}
				}
				setState(130);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class CsvlineContext extends ParserRuleContext {
		public CsvlineContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_csvline; }
	 
		public CsvlineContext() { }
		public void copyFrom(CsvlineContext ctx) {
			super.copyFrom(ctx);
		}
	}
	public static class GetCSVRecordContext extends CsvlineContext {
		public CsvrecordContext csvrecord() {
			return getRuleContext(CsvrecordContext.class,0);
		}
		public GetCSVRecordContext(CsvlineContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof SchemaListener ) ((SchemaListener)listener).enterGetCSVRecord(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof SchemaListener ) ((SchemaListener)listener).exitGetCSVRecord(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof SchemaVisitor ) return ((SchemaVisitor<? extends T>)visitor).visitGetCSVRecord(this);
			else return visitor.visitChildren(this);
		}
	}

	public final CsvlineContext csvline() throws RecognitionException {
		CsvlineContext _localctx = new CsvlineContext(_ctx, getState());
		enterRule(_localctx, 32, RULE_csvline);
		try {
			_localctx = new GetCSVRecordContext(_localctx);
			enterOuterAlt(_localctx, 1);
			{
			setState(131); csvrecord(0);
			setState(132); match(1);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class CsvrecordContext extends ParserRuleContext {
		public int _p;
		public CsvrecordContext(ParserRuleContext parent, int invokingState) { super(parent, invokingState); }
		public CsvrecordContext(ParserRuleContext parent, int invokingState, int _p) {
			super(parent, invokingState);
			this._p = _p;
		}
		@Override public int getRuleIndex() { return RULE_csvrecord; }
	 
		public CsvrecordContext() { }
		public void copyFrom(CsvrecordContext ctx) {
			super.copyFrom(ctx);
			this._p = ctx._p;
		}
	}
	public static class GetFirstCSVEntryContext extends CsvrecordContext {
		public CsventryContext csventry() {
			return getRuleContext(CsventryContext.class,0);
		}
		public GetFirstCSVEntryContext(CsvrecordContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof SchemaListener ) ((SchemaListener)listener).enterGetFirstCSVEntry(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof SchemaListener ) ((SchemaListener)listener).exitGetFirstCSVEntry(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof SchemaVisitor ) return ((SchemaVisitor<? extends T>)visitor).visitGetFirstCSVEntry(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class GetNextCSVEntryContext extends CsvrecordContext {
		public TerminalNode COMMA() { return getToken(SchemaParser.COMMA, 0); }
		public CsvrecordContext csvrecord() {
			return getRuleContext(CsvrecordContext.class,0);
		}
		public CsventryContext csventry() {
			return getRuleContext(CsventryContext.class,0);
		}
		public GetNextCSVEntryContext(CsvrecordContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof SchemaListener ) ((SchemaListener)listener).enterGetNextCSVEntry(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof SchemaListener ) ((SchemaListener)listener).exitGetNextCSVEntry(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof SchemaVisitor ) return ((SchemaVisitor<? extends T>)visitor).visitGetNextCSVEntry(this);
			else return visitor.visitChildren(this);
		}
	}

	public final CsvrecordContext csvrecord(int _p) throws RecognitionException {
		ParserRuleContext _parentctx = _ctx;
		int _parentState = getState();
		CsvrecordContext _localctx = new CsvrecordContext(_ctx, _parentState, _p);
		CsvrecordContext _prevctx = _localctx;
		int _startState = 34;
		enterRecursionRule(_localctx, RULE_csvrecord);
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			{
			_localctx = new GetFirstCSVEntryContext(_localctx);
			_ctx = _localctx;
			_prevctx = _localctx;

			setState(135); csventry();
			}
			_ctx.stop = _input.LT(-1);
			setState(142);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,8,_ctx);
			while ( _alt!=2 && _alt!=-1 ) {
				if ( _alt==1 ) {
					if ( _parseListeners!=null ) triggerExitRuleEvent();
					_prevctx = _localctx;
					{
					{
					_localctx = new GetNextCSVEntryContext(new CsvrecordContext(_parentctx, _parentState, _p));
					pushNewRecursionContext(_localctx, _startState, RULE_csvrecord);
					setState(137);
					if (!(1 >= _localctx._p)) throw new FailedPredicateException(this, "1 >= $_p");
					setState(138); match(COMMA);
					setState(139); csventry();
					}
					} 
				}
				setState(144);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,8,_ctx);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			unrollRecursionContexts(_parentctx);
		}
		return _localctx;
	}

	public static class CsventryContext extends ParserRuleContext {
		public CsventryContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_csventry; }
	 
		public CsventryContext() { }
		public void copyFrom(CsventryContext ctx) {
			super.copyFrom(ctx);
		}
	}
	public static class GetCSVBoolContext extends CsventryContext {
		public Token v;
		public TerminalNode FALSE() { return getToken(SchemaParser.FALSE, 0); }
		public TerminalNode TRUE() { return getToken(SchemaParser.TRUE, 0); }
		public GetCSVBoolContext(CsventryContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof SchemaListener ) ((SchemaListener)listener).enterGetCSVBool(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof SchemaListener ) ((SchemaListener)listener).exitGetCSVBool(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof SchemaVisitor ) return ((SchemaVisitor<? extends T>)visitor).visitGetCSVBool(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class GetCSVNumberContext extends CsventryContext {
		public Token v;
		public TerminalNode NUMBER() { return getToken(SchemaParser.NUMBER, 0); }
		public GetCSVNumberContext(CsventryContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof SchemaListener ) ((SchemaListener)listener).enterGetCSVNumber(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof SchemaListener ) ((SchemaListener)listener).exitGetCSVNumber(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof SchemaVisitor ) return ((SchemaVisitor<? extends T>)visitor).visitGetCSVNumber(this);
			else return visitor.visitChildren(this);
		}
	}
	public static class GetCSVQstrContext extends CsventryContext {
		public Token v;
		public TerminalNode QSTRING() { return getToken(SchemaParser.QSTRING, 0); }
		public GetCSVQstrContext(CsventryContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof SchemaListener ) ((SchemaListener)listener).enterGetCSVQstr(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof SchemaListener ) ((SchemaListener)listener).exitGetCSVQstr(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof SchemaVisitor ) return ((SchemaVisitor<? extends T>)visitor).visitGetCSVQstr(this);
			else return visitor.visitChildren(this);
		}
	}

	public final CsventryContext csventry() throws RecognitionException {
		CsventryContext _localctx = new CsventryContext(_ctx, getState());
		enterRule(_localctx, 36, RULE_csventry);
		int _la;
		try {
			setState(148);
			switch (_input.LA(1)) {
			case NUMBER:
				_localctx = new GetCSVNumberContext(_localctx);
				enterOuterAlt(_localctx, 1);
				{
				setState(145); ((GetCSVNumberContext)_localctx).v = match(NUMBER);
				}
				break;
			case TRUE:
			case FALSE:
				_localctx = new GetCSVBoolContext(_localctx);
				enterOuterAlt(_localctx, 2);
				{
				setState(146);
				((GetCSVBoolContext)_localctx).v = _input.LT(1);
				_la = _input.LA(1);
				if ( !(_la==TRUE || _la==FALSE) ) {
					((GetCSVBoolContext)_localctx).v = (Token)_errHandler.recoverInline(this);
				}
				consume();
				}
				break;
			case QSTRING:
				_localctx = new GetCSVQstrContext(_localctx);
				enterOuterAlt(_localctx, 3);
				{
				setState(147); ((GetCSVQstrContext)_localctx).v = match(QSTRING);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public boolean sempred(RuleContext _localctx, int ruleIndex, int predIndex) {
		switch (ruleIndex) {
		case 5: return constraints_sempred((ConstraintsContext)_localctx, predIndex);

		case 12: return proplist_sempred((ProplistContext)_localctx, predIndex);

		case 17: return csvrecord_sempred((CsvrecordContext)_localctx, predIndex);
		}
		return true;
	}
	private boolean constraints_sempred(ConstraintsContext _localctx, int predIndex) {
		switch (predIndex) {
		case 0: return 1 >= _localctx._p;
		}
		return true;
	}
	private boolean csvrecord_sempred(CsvrecordContext _localctx, int predIndex) {
		switch (predIndex) {
		case 2: return 1 >= _localctx._p;
		}
		return true;
	}
	private boolean proplist_sempred(ProplistContext _localctx, int predIndex) {
		switch (predIndex) {
		case 1: return 1 >= _localctx._p;
		}
		return true;
	}

	public static final String _serializedATN =
		"\2\3\26\u0099\4\2\t\2\4\3\t\3\4\4\t\4\4\5\t\5\4\6\t\6\4\7\t\7\4\b\t\b"+
		"\4\t\t\t\4\n\t\n\4\13\t\13\4\f\t\f\4\r\t\r\4\16\t\16\4\17\t\17\4\20\t"+
		"\20\4\21\t\21\4\22\t\22\4\23\t\23\4\24\t\24\3\2\3\2\3\2\7\2,\n\2\f\2\16"+
		"\2/\13\2\3\3\3\3\3\3\3\3\5\3\65\n\3\3\4\3\4\3\4\3\4\3\4\3\5\7\5=\n\5\f"+
		"\5\16\5@\13\5\3\6\3\6\3\6\3\6\3\7\3\7\3\7\3\7\3\7\3\7\7\7L\n\7\f\7\16"+
		"\7O\13\7\3\b\3\b\3\b\3\b\3\t\3\t\3\n\3\n\3\n\5\nZ\n\n\3\13\3\13\3\13\3"+
		"\13\3\13\3\13\3\f\3\f\3\f\3\f\3\f\3\r\3\r\3\r\3\r\3\r\3\16\3\16\3\16\3"+
		"\16\3\16\3\16\7\16r\n\16\f\16\16\16u\13\16\3\17\3\17\3\17\3\20\3\20\3"+
		"\20\3\20\5\20~\n\20\3\21\7\21\u0081\n\21\f\21\16\21\u0084\13\21\3\22\3"+
		"\22\3\22\3\23\3\23\3\23\3\23\3\23\3\23\7\23\u008f\n\23\f\23\16\23\u0092"+
		"\13\23\3\24\3\24\3\24\5\24\u0097\n\24\3\24\2\25\2\4\6\b\n\f\16\20\22\24"+
		"\26\30\32\34\36 \"$&\2\t\3\21\22\3\21\22\3\5\6\3\21\22\3\21\22\3\21\22"+
		"\3\5\6\u0095\2-\3\2\2\2\4\64\3\2\2\2\6\66\3\2\2\2\b>\3\2\2\2\nA\3\2\2"+
		"\2\fE\3\2\2\2\16P\3\2\2\2\20T\3\2\2\2\22Y\3\2\2\2\24[\3\2\2\2\26a\3\2"+
		"\2\2\30f\3\2\2\2\32k\3\2\2\2\34v\3\2\2\2\36}\3\2\2\2 \u0082\3\2\2\2\""+
		"\u0085\3\2\2\2$\u0088\3\2\2\2&\u0096\3\2\2\2()\5\4\3\2)*\7\3\2\2*,\3\2"+
		"\2\2+(\3\2\2\2,/\3\2\2\2-+\3\2\2\2-.\3\2\2\2.\3\3\2\2\2/-\3\2\2\2\60\65"+
		"\5\26\f\2\61\65\5\24\13\2\62\65\5\30\r\2\63\65\5\6\4\2\64\60\3\2\2\2\64"+
		"\61\3\2\2\2\64\62\3\2\2\2\64\63\3\2\2\2\65\5\3\2\2\2\66\67\7\b\2\2\67"+
		"8\7\25\2\289\7\4\2\29:\t\2\2\2:\7\3\2\2\2;=\5\n\6\2<;\3\2\2\2=@\3\2\2"+
		"\2><\3\2\2\2>?\3\2\2\2?\t\3\2\2\2@>\3\2\2\2AB\5\f\7\2BC\t\3\2\2CD\7\3"+
		"\2\2D\13\3\2\2\2EF\b\7\1\2FG\5\16\b\2GM\3\2\2\2HI\6\7\2\3IJ\7\23\2\2J"+
		"L\5\16\b\2KH\3\2\2\2LO\3\2\2\2MK\3\2\2\2MN\3\2\2\2N\r\3\2\2\2OM\3\2\2"+
		"\2PQ\7\25\2\2QR\5\20\t\2RS\5\22\n\2S\17\3\2\2\2TU\7\24\2\2U\21\3\2\2\2"+
		"VZ\7\7\2\2WZ\t\4\2\2XZ\7\4\2\2YV\3\2\2\2YW\3\2\2\2YX\3\2\2\2Z\23\3\2\2"+
		"\2[\\\7\17\2\2\\]\5\36\20\2]^\7\t\2\2^_\7\25\2\2_`\t\5\2\2`\25\3\2\2\2"+
		"ab\7\r\2\2bc\7\25\2\2cd\5\32\16\2de\t\6\2\2e\27\3\2\2\2fg\7\16\2\2gh\7"+
		"\25\2\2hi\7\4\2\2ij\t\7\2\2j\31\3\2\2\2kl\b\16\1\2lm\5\34\17\2ms\3\2\2"+
		"\2no\6\16\3\3op\7\23\2\2pr\5\34\17\2qn\3\2\2\2ru\3\2\2\2sq\3\2\2\2st\3"+
		"\2\2\2t\33\3\2\2\2us\3\2\2\2vw\5\36\20\2wx\7\25\2\2x\35\3\2\2\2y~\7\n"+
		"\2\2z~\7\13\2\2{~\7\f\2\2|~\7\25\2\2}y\3\2\2\2}z\3\2\2\2}{\3\2\2\2}|\3"+
		"\2\2\2~\37\3\2\2\2\177\u0081\5\"\22\2\u0080\177\3\2\2\2\u0081\u0084\3"+
		"\2\2\2\u0082\u0080\3\2\2\2\u0082\u0083\3\2\2\2\u0083!\3\2\2\2\u0084\u0082"+
		"\3\2\2\2\u0085\u0086\5$\23\2\u0086\u0087\7\3\2\2\u0087#\3\2\2\2\u0088"+
		"\u0089\b\23\1\2\u0089\u008a\5&\24\2\u008a\u0090\3\2\2\2\u008b\u008c\6"+
		"\23\4\3\u008c\u008d\7\23\2\2\u008d\u008f\5&\24\2\u008e\u008b\3\2\2\2\u008f"+
		"\u0092\3\2\2\2\u0090\u008e\3\2\2\2\u0090\u0091\3\2\2\2\u0091%\3\2\2\2"+
		"\u0092\u0090\3\2\2\2\u0093\u0097\7\7\2\2\u0094\u0097\t\b\2\2\u0095\u0097"+
		"\7\4\2\2\u0096\u0093\3\2\2\2\u0096\u0094\3\2\2\2\u0096\u0095\3\2\2\2\u0097"+
		"\'\3\2\2\2\f-\64>MYs}\u0082\u0090\u0096";
	public static final ATN _ATN =
		ATNSimulator.deserialize(_serializedATN.toCharArray());
	static {
		_decisionToDFA = new DFA[_ATN.getNumberOfDecisions()];
	}
}